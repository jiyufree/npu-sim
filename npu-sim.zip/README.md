# npu-sim

MAC(Multiply-Accumulate) 연산으로 십자가(Cross)/X 패턴을 판별하는 **Mini NPU Simulator** 과제 저장소입니다.

- 코드와 상세 문서: [`npu-sim/`](npu-sim/) → [`npu-sim/README.md`](npu-sim/README.md)
- 실행: `cd npu-sim && python main.py` (Python 3.8+, 외부 라이브러리 없음)
